import wg_easy_api_wrapper
import aiohttp

async def get_clients(host, port, _password):
        async with aiohttp.ClientSession() as session:
            api_client = wg_easy_api_wrapper.Server(host, port, _password, session)
            await api_client.login()
            answer = await api_client.get_clients()
        return answer

async def remove_client(host, port, _password, uid:str):
        async with aiohttp.ClientSession() as session:
            api_client = wg_easy_api_wrapper.Server(host, port, _password, session)
            await api_client.login()
            await api_client.remove_client(uid)

async def create_client(host, port, _password, name:str):
        async with aiohttp.ClientSession() as session:
            api_client = wg_easy_api_wrapper.Server(host, port, _password, session)
            await api_client.login()
            await api_client.create_client(name)

async def get_client(host, port, _password, uid:str):
        async with aiohttp.ClientSession() as session:
            api_client = wg_easy_api_wrapper.Server(host, port, _password, session)
            await api_client.login()
            client = await api_client.get_client(uid)
            return client

async def get_conf(host, port, _password, uid:str):
      async with aiohttp.ClientSession() as session:
            api_client = wg_easy_api_wrapper.Server(host, port, _password, session)
            await api_client.login()
            client = await api_client.get_client(uid)
            conf = await client.get_configuration()
            return conf
      
async def get_qr(host, port, _password, uid:str):
    async with aiohttp.ClientSession() as session:
            api_client = wg_easy_api_wrapper.Server(host, port, _password, session)
            await api_client.login()
            client = await api_client.get_client(uid)
            qr = await client.get_qr_code()
            qr_image = await qr.text()
            return qr_image