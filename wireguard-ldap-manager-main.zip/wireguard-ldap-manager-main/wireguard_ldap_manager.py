import sys
import ldap3
import asyncio
import apiwrapper

def is_user_in_wglist(username, clients):
    for client in clients:
        if (username == client.name):
            return True
    return False

def is_client_in_ldaplist(client, users):
    for user in users:
        if (user['nsaccountlock'] != 'TRUE'):
            if (user['uid'] == client.name):
                return True
    return False

# Setting constants
LDAP_BIND_USER="uid=service.user,cn=users,cn=accounts,dc=napoleonit,dc=ru"
LDAP_PASS="G6W&^4DTZTXjQu"
BASE_DN="cn=users,cn=accounts,dc=napoleonit,dc=ru"
LDAP_GROUP_FILTER="(memberOf=cn=wireguard*)"
WIREGUARD_URL = "hetzner-wg.itnap.ru"
WIREGUARD_PORT = 51821
WIREGUARD_PASS = "eM248P9rQFmSSlU0"

ipa_server = ldap3.Server("ipa-master.napoleonit.ru", get_info=ldap3.ALL)
connection = ldap3.Connection(ipa_server, LDAP_BIND_USER, LDAP_PASS, auto_bind=True)

connection.search(BASE_DN, LDAP_GROUP_FILTER, attributes=['uid', 'mail', 'nsaccountlock'])
users = connection.entries

if len(users) == 0:
    print("Got an empty response from LDAP, something is wrong!")
    sys.exit()

clients = asyncio.run(apiwrapper.get_clients(WIREGUARD_URL, WIREGUARD_PORT, WIREGUARD_PASS))


for user in users:
    if (user['nsaccountlock'] != 'TRUE'):
        if (not is_user_in_wglist(user['uid'], clients)):
            asyncio.run(apiwrapper.create_client(WIREGUARD_URL, WIREGUARD_PORT, WIREGUARD_PASS, str(user['uid'])))

for client in clients:
    if (not is_client_in_ldaplist(client, users)):
        print(client.uid)
        asyncio.run(apiwrapper.remove_client(WIREGUARD_URL, WIREGUARD_PORT, WIREGUARD_PASS, client.uid))


