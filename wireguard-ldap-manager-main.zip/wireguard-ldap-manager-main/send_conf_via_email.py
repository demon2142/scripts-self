import sys
import ldap3
import asyncio
import apiwrapper
import smtplib, ssl
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import os

# Setting constants
LDAP_BIND_USER="uid=service.user,cn=users,cn=accounts,dc=napoleonit,dc=ru"
LDAP_PASS="G6W&^4DTZTXjQu"
BASE_DN="cn=users,cn=accounts,dc=napoleonit,dc=ru"
WIREGUARD_URL = "hetzner-wg.itnap.ru"
WIREGUARD_PORT = 51821
WIREGUARD_PASS = "eM248P9rQFmSSlU0"
SMTP_SERVER = "smtp.yandex.ru"
SMTP_PORT = 465
SENDER_EMAIL = "no-reply@napoleonit.ru"
SENDER_PASS = "jxmivnfsdbiwhhoa"
SUBJECT = "Wireguard config"
BODY = "Конфигурационный файл и QR-код для wireguard во вложениях.\nИнструкция для подключения находится по ссылке: https://www.wireguard.com/install/\n\n-------------\n\nДанное сообщение отправлено автоматически, отвечать на него не требуется."

clients = asyncio.run(apiwrapper.get_clients(WIREGUARD_URL, WIREGUARD_PORT, WIREGUARD_PASS))

ipa_server = ldap3.Server("ipa-master.napoleonit.ru", get_info=ldap3.ALL)
connection = ldap3.Connection(ipa_server, LDAP_BIND_USER, LDAP_PASS, auto_bind=True)

for client in clients:
    username = client.name
    connection.search(BASE_DN, f'(uid={username})', attributes=['uid', 'mail', 'nsaccountlock'])
    ldap_user = connection.entries
    receiver_email = ldap_user[0]['mail'][0]
    message = MIMEMultipart()
    message["From"] = SENDER_EMAIL
    message["TO"] = receiver_email
    message["Subject"] = SUBJECT
    message["Bss"] = receiver_email
    message.attach(MIMEText(BODY, "plain"))

    conf_file = asyncio.run(apiwrapper.get_conf(WIREGUARD_URL, WIREGUARD_PORT, WIREGUARD_PASS, client.uid))
    part_conf = MIMEBase("text", "plain")
    part_conf.set_payload(conf_file)
    encoders.encode_base64(part_conf)
    part_conf.add_header(
        "Content-Disposition",
        f"attachment; filename= {username}_wireguard.conf",
    )

    qr_file = asyncio.run(apiwrapper.get_qr(WIREGUARD_URL, WIREGUARD_PORT, WIREGUARD_PASS, client.uid))
    part_qr = MIMEBase("image", "svg/xml")
    part_qr.set_payload(qr_file)
    encoders.encode_base64(part_qr)
    part_qr.add_header(
        "Content-Disposition",
        f"attachment; filename= QR_{username}_wireguard.svg",
    )

    message.attach(part_conf)
    message.attach(part_qr)
    text = message.as_string()
    
    # Create a secure SSL context
    context = ssl.create_default_context()
    with smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT, context=context) as server:
        server.login(SENDER_EMAIL, SENDER_PASS)            
        server.sendmail(SENDER_EMAIL, receiver_email, text)
    #print(f'Sending mail to {receiver_email} username: {username}')
